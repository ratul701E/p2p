export interface BlockDTO {
    id: string
    miner: string
}
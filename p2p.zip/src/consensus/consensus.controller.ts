import { Controller } from '@nestjs/common';

@Controller('consensus')
export class ConsensusController {}
